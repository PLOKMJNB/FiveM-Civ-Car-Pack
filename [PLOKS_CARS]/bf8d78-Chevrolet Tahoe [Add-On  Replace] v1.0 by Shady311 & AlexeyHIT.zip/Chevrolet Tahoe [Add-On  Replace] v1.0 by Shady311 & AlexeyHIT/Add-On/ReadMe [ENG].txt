﻿[How to add this car as an add-on]

Installation:
[Editing the dlclist.xml]
1. Using OpenIV, extract the contents of the folder "x64" to: \Grand Theft Auto V\mods\update\x64\dlcpacks
2. Using OpenIV, go to: \Grand Theft Auto V\update\update.rpf\common\data — and extract the "dlclist.xml" in some folder of your choice.
3. Add the following line: 

		<Item>dlcpacks:\tahoe\</Item>

4. Save the changes and copy the edited "dlclist.xml" back to: \Grand Theft Auto V\update\update.rpf\common\data

[Editing the extratitleupdatedata.meta]
5. Using OpenIV, go to: \Grand Theft Auto V\update\update.rpf\common\data — and extract the "extratitleupdatedata.meta" in some folder of your choice.
6. Add the following line:

		<Item type="SExtraTitleUpdateMount">
			<deviceName>dlc_tahoe:/</deviceName>
			<path>update:/dlc_patch/tahoe/</path>
		</Item>

7. Save the changes and copy the edited "extratitleupdatedata.meta" to: \Grand Theft Auto V\update\update.rpf\common\data
8. Then, go to :\Grand Theft Auto V — open trainerv.ini — f //Added Cars // section
9. Change Enable1=0 to Enable1=1
10. Change ModelName1=turismo to ModelName1=tahoe
Change DisplayName1=Car 1 to DisplayName1=Chevrolet Tahoe
11. Save the changes and copy the edited "trainerv.ini" to: \Grand Theft Auto V

Done!

Instruction by: Alex9581 http://maniamods.ru/