﻿[Данная оригинальная копия архива скачана с http://maniamods.ru/]

До 14.07.2016 модель является эксклюзивом для сайта ManiaMods.ru !

~ MANIAMODS EXCLUSIVE ~

ЗАПРЕЩЕНО РАЗМЕЩЕНИЕ НА ЛЮБОМ РЕСУРСЕ ДО 14.07.2016 !


Chevrolet Tahoe v1.0 для GTA 5 by Shady311, AlexeyHIT

           Автор оригинальной 3D модели: Shady311
           Автор конвертирования и доработки в ГТА 5: AlexeyHIT
           Автор всех настроек, способа добавления модели и доработок: Alex9581

Особенности модели: 

           Модель поддерживает все основные функции игры;
           По всему кузову авто остаются отверстия от пуль;
           Правильный функционал всей оптики;
           Правильные пропорции модели;
           Собственная коллизия;
           Руки персонажа на руле;
           Реалистичные отражения в зеркалах;
           Рабочая панель приборов;
           Корректные повреждения, все как у оригинальных машин в игре;
           Реалистичные настройки handling.meta и vehicles.meta.

Заменяет: rancherxl

Установка и настройка                                                                                      

[Установка]

Вручную:
С помощью программы OpenIV перейдите по пути (#:\Grand Theft Auto V\mods\x64e.rpf\levels\gta5\vehicles.rpf\)
Найдите файлы rancherxl.yft, rancherxl.ytd и rancherxl_hi.yft, и замените их файлами из данного архива
	
[Настройка]
[ВНИМАНИЕ!] Модель без установки нижеследующих настроек будет работать некорректно! В частности будет переворачиваться при резком повороте руля!

Откройте "Блокнотом" файл handling.meta (#:\ Grand Theft Auto V \ update \ update.rpf \ common \) 
Найдите строку, которая начинается с "rancherxl", и замените от <Item type="CHandlingData"> до </Item> к данной модели.
Аналогичную процедуру проделайте с файлом vehicles.meta


[handling.meta]    
    <Item type="CHandlingData">
      <handlingName>RANCHERXL</handlingName>
      <fMass value="2400.000000" />
      <fInitialDragCoeff value="1.220000" />
      <fPercentSubmerged value="85.000000" />
      <vecCentreOfMassOffset x="0.000000" y="0.050000" z="0.000000" />
      <vecInertiaMultiplier x="1.000000" y="1.000000" z="1.450000" />
      <fDriveBiasFront value="0.300000" />
      <nInitialDriveGears value="6" />
      <fInitialDriveForce value="0.250000" />
      <fDriveInertia value="1.000000" />
      <fClutchChangeRateScaleUpShift value="2.500000" />
      <fClutchChangeRateScaleDownShift value="2.500000" />
      <fInitialDriveMaxFlatVel value="168.800000" />
      <fBrakeForce value="1.000000" />
      <fBrakeBiasFront value="0.425000" />
      <fHandBrakeForce value="0.450000" />
      <fSteeringLock value="40.200000" />
      <fTractionCurveMax value="2.690000" />
      <fTractionCurveMin value="2.560000" />
      <fTractionCurveLateral value="22.500000" />
      <fTractionSpringDeltaMax value="0.150000" />
      <fLowSpeedTractionLossMult value="0.800000" />
      <fCamberStiffnesss value="0.000000" />
      <fTractionBiasFront value="0.493000" />
      <fTractionLossMult value="1.000000" />
      <fSuspensionForce value="2.800000" />
      <fSuspensionCompDamp value="1.500000" />
      <fSuspensionReboundDamp value="2.800000" />
      <fSuspensionUpperLimit value="0.100000" />
      <fSuspensionLowerLimit value="-0.100000" />
      <fSuspensionRaise value="0.000000" />
      <fSuspensionBiasFront value="0.520000" />
      <fAntiRollBarForce value="0.000000" />
      <fAntiRollBarBiasFront value="0.500000" />
      <fRollCentreHeightFront value="0.190000" />
      <fRollCentreHeightRear value="0.200000" />
      <fCollisionDamageMult value="1.000000" />
      <fWeaponDamageMult value="1.000000" />
      <fDeformationDamageMult value="0.800000" />
      <fEngineDamageMult value="1.500000" />
      <fPetrolTankVolume value="65.000000" />
      <fOilVolume value="5.000000" />
      <fSeatOffsetDistX value="0.000000" />
      <fSeatOffsetDistY value="0.000000" />
      <fSeatOffsetDistZ value="0.000000" />
      <nMonetaryValue value="50000" />
      <strModelFlags>440010</strModelFlags>
      <strHandlingFlags>0</strHandlingFlags>
      <strDamageFlags>0</strDamageFlags>
      <AIHandling>AVERAGE</AIHandling>
      <SubHandlingData>
        <Item type="CCarHandlingData">
          <fBackEndPopUpCarImpulseMult value="0.100000" />
          <fBackEndPopUpBuildingImpulseMult value="0.030000" />
          <fBackEndPopUpMaxDeltaSpeed value="0.600000" />
        </Item>
        <Item type="NULL" />
        <Item type="NULL" />
      </SubHandlingData>
    </Item>

[vehicles.meta]
Путь: \Grand Theft Auto V\update\update.rpf\common\data\levels\gta5
    <Item>
      <modelName>rancherxl</modelName>
      <txdName>rancherxl</txdName>
      <handlingId>RANCHERXL</handlingId>
      <gameName>RANCHERX</gameName>
      <vehicleMakeName>DECLASSE</vehicleMakeName>
      <expressionDictName>null</expressionDictName>
      <expressionName>null</expressionName>
      <animConvRoofDictName>null</animConvRoofDictName>
      <animConvRoofName>null</animConvRoofName>
      <animConvRoofWindowsAffected />
      <ptfxAssetName>null</ptfxAssetName>
      <audioNameHash />
      <layout>LAYOUT_RANGER</layout>
      <coverBoundOffsets>RANCHERXL_COVER_OFFSET_INFO</coverBoundOffsets>
      <explosionInfo>EXPLOSION_INFO_DEFAULT</explosionInfo>
      <scenarioLayout />
      <cameraName>DEFAULT_FOLLOW_VEHICLE_CAMERA</cameraName>
      <aimCameraName>MID_BOX_VEHICLE_AIM_CAMERA</aimCameraName>
      <bonnetCameraName>VEHICLE_BONNET_CAMERA_MID</bonnetCameraName>
      <povCameraName>DEFAULT_POV_CAMERA_LOOKAROUND_MID</povCameraName>
      <FirstPersonDriveByIKOffset x="0.023000" y="-0.050000" z="-0.030000" />
      <FirstPersonDriveByIKOffset x="0.000000" y="-0.035000" z="0.000000" />
      <FirstPersonDriveByUnarmedIKOffset x="0.000000" y="-0.025000" z="0.000000" />
	  <FirstPersonProjectileDriveByIKOffset x="0.050000" y="-0.085000" z="-0.030000" />
	  <FirstPersonProjectileDriveByPassengerIKOffset x="0.020000" y="0.060000" z="-0.090000" />
	  <FirstPersonProjectileDriveByRearLeftIKOffset x="0.000000" y="0.000000" z="-0.083000" />
	  <FirstPersonProjectileDriveByRearRightIKOffset x="0.000000" y="0.000000" z="-0.083000" />
	  <FirstPersonDriveByLeftPassengerIKOffset x="-0.015000" y="0.010000" z="-0.050000" />
	  <FirstPersonDriveByRightPassengerIKOffset x="0.000000" y="-0.060000" z="-0.040000" />
	  <FirstPersonDriveByRightRearPassengerIKOffset x="-0.015000" y="0.010000" z="-0.050000" />
	  <FirstPersonDriveByLeftPassengerUnarmedIKOffset x="0.110000" y="0.000000" z="-0.020000" />
	  <FirstPersonDriveByRightPassengerUnarmedIKOffset x="-0.1100000" y="0.000000" z="-0.020000" />
	  <FirstPersonMobilePhoneOffset x="0.155000" y="0.315000" z="0.450000" />
      <FirstPersonPassengerMobilePhoneOffset x="0.174000" y="0.241000" z="0.420000" />
      <PovCameraOffset x="0.000000" y="-0.180000" z="0.520000" />
      <PovCameraVerticalAdjustmentForRollCage value="0.000000" />
      <PovPassengerCameraOffset x="0.000000" y="0.000000" z="0.070000" />
      <PovRearPassengerCameraOffset x="0.000000" y="0.000000" z="0.070000" />
      <vfxInfoName>VFXVEHICLEINFO_CAR_OFFROAD</vfxInfoName>
      <shouldUseCinematicViewMode value="true" />
      <shouldCameraTransitionOnClimbUpDown value="false" />
      <shouldCameraIgnoreExiting value="false" />
      <AllowPretendOccupants value="true" />
      <AllowJoyriding value="true" />
      <AllowSundayDriving value="true" />
      <AllowBodyColorMapping value="true" />
      <wheelScale value="0.244000" />
      <wheelScaleRear value="0.244000" />
      <dirtLevelMin value="0.300000" />
      <dirtLevelMax value="0.850000" />
      <envEffScaleMin value="0.000000" />
      <envEffScaleMax value="1.000000" />
      <envEffScaleMin2 value="0.000000" />
      <envEffScaleMax2 value="1.000000" />
      <damageMapScale value="0.600000" />
      <damageOffsetScale value="1.000000" />
      <diffuseTint value="0xAA0A0A0A" />
      <steerWheelMult value="1.000000" />
      <HDTextureDist value="5.000000" />
      <lodDistances content="float_array">
      450.000000    
      460.000000    
      470.000000    
      480.000000    
      500.000000    
      500.000000 
      </lodDistances>
      <minSeatHeight value="0.876" />
      <identicalModelSpawnDistance value="20" />
      <maxNumOfSameColor value="10" />
      <defaultBodyHealth value="1000.000000" />
      <pretendOccupantsScale value="1.000000" />
      <visibleSpawnDistScale value="1.000000" />
      <trackerPathWidth value="2.000000" />
      <weaponForceMult value="1.000000" />
      <frequency value="100" />
      <swankness>SWANKNESS_1</swankness>
      <maxNum value="999" />
      <flags>FLAG_AVERAGE_CAR FLAG_POOR_CAR FLAG_USE_HIGHER_DOOR_TORQUE FLAG_IS_BULKY FLAG_ATTACH_TRAILER_ON_HIGHWAY FLAG_HAS_INTERIOR_EXTRAS</flags>
      <type>VEHICLE_TYPE_CAR</type>
      <plateType>VPT_FRONT_AND_BACK_PLATES</plateType>
	  <dashboardType>VDT_BOBCAT</dashboardType>
      <vehicleClass>VC_OFF_ROAD</vehicleClass>
      <wheelType>VWT_OFFROAD</wheelType>
      <trailers>
        <Item>boattrailer</Item>
        <Item>trailersmall</Item>
      </trailers>
      <additionalTrailers />
      <drivers />
      <extraIncludes />
      <doorsWithCollisionWhenClosed />
      <driveableDoors />
      <bumpersNeedToCollideWithMap value="false" />
      <needsRopeTexture value="false" />
      <requiredExtras />
      <rewards />
      <cinematicPartCamera>
        <Item>WHEEL_FRONT_RIGHT_CAMERA</Item>
        <Item>WHEEL_FRONT_LEFT_CAMERA</Item>
        <Item>WHEEL_REAR_RIGHT_CAMERA</Item>
        <Item>WHEEL_REAR_LEFT_CAMERA</Item>
      </cinematicPartCamera>
      <NmBraceOverrideSet>Truck</NmBraceOverrideSet>
      <buoyancySphereOffset x="0.000000" y="0.000000" z="0.000000" />
      <buoyancySphereSizeScale value="1.000000" />
      <pOverrideRagdollThreshold type="NULL" />
      <firstPersonDrivebyData>
        <Item>RANGER_RANCHERXL_FRONT_LEFT</Item>
        <Item>RANGER_FRONT_RIGHT</Item>
        <Item>RANGER_RANCHERXL2_REAR_LEFT</Item>
        <Item>RANGER_RANCHERXL2_REAR_RIGHT</Item>
      </firstPersonDrivebyData>
    </Item>

Условия распространения и использования 

ЗАПРЕЩЕНО РАЗМЕЩЕНИЕ НА ЛЮБОМ РЕСУРСЕ ДО 14.07.2016!
ЗАПРЕЩЕНО ВНОСИТЬ ИЗМЕНЕНИЯ В АРХИВ С МОДИФИКАЦИЕЙ! А ИМЕННО: УДАЛЯТЬ, ПЕРЕИМЕНОВЫВАТЬ СТАНДАРТНЫЕ ФАЙЛЫ; ДОБАВЛЯТЬ СВОИ ФАЙЛЫ;
ЗАПРЕЩЕНО ИСПОЛЬЗОВАТЬ МОДИФИКАЦИЮ В КОММЕРЧЕСКИХ ЦЕЛЯХ!
ЗАПРЕЩЕНО ИСПОЛЬЗОВАТЬ ДЕТАЛИ И ТЕКСТУРЫ МОДЕЛИ В СОБСТВЕННЫХ ЦЕЛЯХ!
ЗАПРЕЩЕНО КОНВЕРТИРОВАНИЕ МОДЕЛИ В ДРУГИЕ ИГРЫ БЕЗ СОГЛАСИЯ АВТОРА МОДИФИКАЦИИ!
!!!!! ЗАПРЕЩЕНО РАЗМЕЩЕНИЕ НА !!!!!!! PLAYGROUND.RU, SAMP-RUS.COM, GTAEXPLORER.RU, GTAVICECITY.RU !!!!!!!
ПРИ РАЗМЕЩЕНИИ ОБЯЗАТЕЛЬНО УКАЗАНИЕ ВСЕХ АВТОРОВ МОДЕЛИ, А ТАКЖЕ САЙТОВ!
ПРИ РАЗМЕЩЕНИИ МОДИФИКАЦИИ НА СТОРОННЕМ САЙТЕ ИСПОЛЬЗОВАТЬ ОРИГИНАЛЬНЫЕ СКРИНШОТЫ ИЗ АРХИВА!
ЗАПРЕЩЕНО ЗАГРУЖАТЬ АРХИВ НА DEPOSITFILES.COM И ПОДОБНЫМ ОБМЕННИКАМ!
[Список всех файлов которые ДОЛЖНЫ БЫТЬ в архиве при размещении на стороннем сайте. Любых других посторонних файлов быть не должно!]

Chevrolet Tahoe.jpg
[RUS] ReadMe.txt
[ENG] ReadMe.txt
Папка "Replace"	
Папка "Add-On"	
rancherxl.yft (2.82 MB)
rancherxl_hi.yft (2.83 MB)
rancherxl.ytd (11.9 MB)
Папка "Screenshots" (с картинками внутри)
Screenshots 1.jpg
Screenshots 2.jpg
Папка "Links" (c файлами ссылок внутри)
GTA 5 и GTA 4 - новости, статьи, моды - ManiaMods.ru.URL
ManiaMods  GTA 5, GTA 4 - Google+.URL
ManiaMods  GTA 5, GTA 4 - ВКонтакте.URL

Размер оригинального архива 18.1 MB

Пожалуйста, НЕ изменяйте архив! Уважайте чужой труд! 
Во избежании неприятных ситуаций, просим перед размещением модификации на своем сайте, загрузить оригинальный архив с ManiaMods.ru ! 

Сайт и официальные группы Автора:

http://maniamods.ru/
https://vk.com/maniamods

ManiaMods.ru © 2014-2016

Дата релиза: [30.06.2016]